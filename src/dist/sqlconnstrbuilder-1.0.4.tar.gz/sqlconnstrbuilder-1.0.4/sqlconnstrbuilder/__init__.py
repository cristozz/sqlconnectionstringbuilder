__version__ = "1.0.4"

from sqlconnstrbuilder.sqlconnectionstringbuilder import SqlConnectionStringBuilder